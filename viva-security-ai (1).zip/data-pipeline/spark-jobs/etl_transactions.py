from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("VivaLoginETL").getOrCreate()

df = spark.read.format("kafka") \
    .option("kafka.bootstrap.servers", "kafka:9092") \
    .option("subscribe", "login_events") \
    .load()

df.write.format("parquet").save("/data/processed_logins/")
