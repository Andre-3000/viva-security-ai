from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np

app = FastAPI()
model = joblib.load("../../ml-models/user-behavior/model.joblib")

class UserBehavior(BaseModel):
    login_hour: int
    session_duration: int
    ip_distance: float

@app.post("/predict")
def predict(behavior: UserBehavior):
    data = np.array([[behavior.login_hour, behavior.session_duration, behavior.ip_distance]])
    pred = model.predict(data)
    result = "anomalous" if pred[0] == -1 else "normal"
    return {"result": result}
