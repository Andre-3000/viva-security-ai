import pandas as pd
from sklearn.ensemble import IsolationForest
import joblib

data = pd.DataFrame({
    "login_hour": [9, 10, 11, 22, 23, 0],
    "session_duration": [300, 450, 200, 50, 600, 20],
    "ip_distance": [0, 1, 2, 15, 30, 100]
})

model = IsolationForest(n_estimators=100, contamination=0.2)
model.fit(data)

joblib.dump(model, "model.joblib")
print("Model saved.")
